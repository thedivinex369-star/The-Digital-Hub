# The Digital Hub — Store v3

This version keeps the existing frontend and adds a real Node/Express checkout backend prepared for Razorpay and protected digital downloads.

## 1. Install
- Install Node.js 18+.
- Open this folder in Terminal.
- Run `npm install`.
- Copy `.env.example` to `.env` and add your Razorpay test/live keys.
- Add your actual paid files inside `private-files/` using the filenames in `products.json`.

## 2. Run
`npm start`
Then open `http://localhost:3000`.

## 3. Payment flow
Cart → `/api/create-order` → Razorpay Checkout → `/api/verify-payment` → protected 24-hour download links → optional email delivery.

## 4. Email
Set SMTP variables in `.env`. For Gmail, use an App Password rather than your normal password.

## 5. Production checklist
- Use HTTPS and your real domain.
- Use Razorpay live keys only after testing.
- Set `BASE_URL` to the real HTTPS domain.
- Configure Razorpay webhook using `/api/webhook/razorpay` and the same webhook secret.
- Move order storage from `orders.json` to a managed database before high-volume production.
- Keep `private-files/` outside any public CDN/web root.
- Never put Razorpay secret keys in frontend JavaScript.
- Add admin authentication before adding product-management screens.
