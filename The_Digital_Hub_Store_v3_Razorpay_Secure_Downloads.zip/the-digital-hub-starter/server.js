require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const helmet = require('helmet');
const morgan = require('morgan');
const Razorpay = require('razorpay');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const ROOT = __dirname;
const PRIVATE = path.join(ROOT, 'private-files');
const products = JSON.parse(fs.readFileSync(path.join(ROOT, 'products.json'), 'utf8'));
const ordersFile = path.join(ROOT, 'orders.json');
if (!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile, '[]');

app.use(helmet({contentSecurityPolicy:false}));
app.use(morgan('tiny'));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(ROOT, {index:'index.html'}));

const razorpay = new Razorpay({key_id:process.env.RAZORPAY_KEY_ID || 'rzp_test_missing', key_secret:process.env.RAZORPAY_KEY_SECRET || 'missing'});
const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:Number(process.env.SMTP_PORT||587)===465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}) : null;

function readOrders(){ return JSON.parse(fs.readFileSync(ordersFile,'utf8')); }
function writeOrders(v){ fs.writeFileSync(ordersFile, JSON.stringify(v,null,2)); }
function productById(id){ return products.find(p=>p.id===id); }
function makeToken(orderId, productId, exp){
  const payload = `${orderId}.${productId}.${exp}`;
  const sig = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'dev-secret').update(payload).digest('hex');
  return Buffer.from(`${payload}.${sig}`).toString('base64url');
}
function verifyToken(token){
  const raw=Buffer.from(token,'base64url').toString('utf8'); const parts=raw.split('.');
  if(parts.length!==4) throw new Error('Invalid token');
  const [orderId,productId,exp,sig]=parts; if(Number(exp)<Date.now()) throw new Error('Token expired');
  const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET||'dev-secret').update(`${orderId}.${productId}.${exp}`).digest('hex');
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) throw new Error('Invalid signature');
  return {orderId,productId};
}

app.get('/api/products',(req,res)=>res.json(products.map(p=>({...p,priceRupees:p.price/100,mrpRupees:p.mrp/100}))));

app.post('/api/create-order', async (req,res)=>{
  try{
    const {items,email,name}=req.body;
    if(!Array.isArray(items)||!items.length) return res.status(400).json({error:'Cart is empty'});
    if(!email || !/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:'Valid email is required'});
    const clean=[]; let amount=0;
    for(const item of items){
      const p=productById(item.id); const qty=Math.max(1,Math.min(10,Number(item.qty)||1));
      if(!p) return res.status(400).json({error:`Product not found: ${item.id}`});
      clean.push({id:p.id,name:p.name,price:p.price,qty}); amount += p.price*qty;
    }
    const receipt=`TDH_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const rpOrder=await razorpay.orders.create({amount,currency:'INR',receipt,notes:{email}});
    const orders=readOrders(); orders.push({id:rpOrder.id,receipt,name:name||'',email,items:clean,amount,status:'created',createdAt:new Date().toISOString()}); writeOrders(orders);
    res.json({keyId:process.env.RAZORPAY_KEY_ID,orderId:rpOrder.id,amount,currency:'INR'});
  }catch(e){ console.error(e); res.status(500).json({error:'Unable to create payment order. Check Razorpay settings.'}); }
});

app.post('/api/verify-payment', async (req,res)=>{
  try{
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
    const orders=readOrders(); const order=orders.find(o=>o.id===razorpay_order_id);
    if(!order) return res.status(404).json({error:'Order not found'});
    const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET||'missing').update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    if(expected!==razorpay_signature) return res.status(400).json({error:'Payment verification failed'});
    order.status='paid'; order.paymentId=razorpay_payment_id; order.paidAt=new Date().toISOString();
    const links=order.items.map(i=>({productId:i.id,productName:i.name,url:`${BASE_URL}/download/${makeToken(order.id,i.id,Date.now()+24*60*60*1000)}`}));
    order.downloads=links; writeOrders(orders);
    if(mailer){
      const html=`<h2>Thank you for your purchase!</h2><p>Your Digital Hub order <b>${order.id}</b> is confirmed.</p><ul>${links.map(l=>`<li><a href="${l.url}">${l.productName} — Download</a></li>`).join('')}</ul><p>Links are valid for 24 hours. You can request a fresh link from support if needed.</p>`;
      await mailer.sendMail({from:process.env.FROM_EMAIL,to:order.email,subject:'Your Digital Hub purchase & download links',html});
    }
    res.json({success:true,orderId:order.id,downloads:links});
  }catch(e){ console.error(e); res.status(500).json({error:'Could not verify payment'}); }
});

app.get('/download/:token',(req,res)=>{
  try{
    const {orderId,productId}=verifyToken(req.params.token); const order=readOrders().find(o=>o.id===orderId && o.status==='paid');
    const p=productById(productId); if(!order||!p||!order.items.some(i=>i.id===productId)) return res.status(404).send('Download not available.');
    const file=path.resolve(PRIVATE,p.file); if(!file.startsWith(PRIVATE+path.sep)||!fs.existsSync(file)) return res.status(404).send('Product file has not been uploaded yet.');
    res.download(file,p.file);
  }catch(e){res.status(403).send('This download link is invalid or expired.');}
});

app.post('/api/webhook/razorpay',(req,res)=>{
  const signature=req.headers['x-razorpay-signature'];
  if(!signature || !process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(400).send('Webhook not configured');
  const body=JSON.stringify(req.body); const expected=crypto.createHmac('sha256',process.env.RAZORPAY_WEBHOOK_SECRET).update(body).digest('hex');
  if(expected!==signature) return res.status(400).send('Invalid webhook signature');
  console.log('Razorpay webhook:',req.body.event); res.json({ok:true});
});

app.get('/api/order/:id',(req,res)=>{const o=readOrders().find(x=>x.id===req.params.id); if(!o)return res.status(404).json({error:'Not found'}); res.json({id:o.id,status:o.status,amount:o.amount/100,email:o.email,downloads:o.status==='paid'?o.downloads||[]:[]});});

app.listen(PORT,()=>console.log(`The Digital Hub running at ${BASE_URL}`));
