# The Digital Hub — Production Launch Checklist

## 1. Hosting
- Use a Node.js 18+ host with HTTPS and persistent storage.
- Upload this project and run `npm install` then `npm start`.
- Set `BASE_URL` to the real HTTPS domain.

## 2. Razorpay
- Start with Razorpay Test Mode.
- Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in environment variables.
- Configure the webhook URL as `https://YOUR-DOMAIN.com/api/webhook/razorpay`.
- Set `RAZORPAY_WEBHOOK_SECRET` to the same secret configured in Razorpay.
- Test successful, failed and cancelled payments before switching to Live Mode.

## 3. Email
- Configure SMTP credentials in environment variables.
- Prefer an SMTP provider/domain mailbox with an app password or SMTP token.
- Test purchase emails and verify the From domain.

## 4. Admin
- Change `ADMIN_USERNAME` and use a long random `ADMIN_PASSWORD`.
- Never commit `.env` to GitHub or upload it publicly.

## 5. Digital files
- Put customer files only inside `private-files/`.
- Never place paid files inside a public/static folder.
- The download route uses signed, expiring links.

## 6. Before launch
- Add your real products and files in Admin.
- Test coupon calculation.
- Test account registration/login.
- Test payment verification and download.
- Test on Android and desktop.
- Enable HTTPS.
- Back up `products.json`, `customers.json`, `orders.json`, `coupons.json`, and `private-files/`.

## Important
This package is a production-oriented foundation, not a hosted/live service by itself. Real payments and emails require your own Razorpay/SMTP credentials and a deployed HTTPS server.
