PUT YOUR PAID DIGITAL PRODUCT FILES HERE.

Example:
private-files/instagram-growth-bundle.zip
private-files/canva-creator-pack.pdf

These files are intentionally outside the public assets folder. The server only sends them after a verified Razorpay payment and a valid short-lived download token.
