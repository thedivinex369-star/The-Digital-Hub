const products = [
  {id:1,name:"Instagram Growth Bundle",category:"Instagram Marketing",price:499,old:999,icon:"📱",desc:"Hooks, captions, content ideas and growth resources."},
  {id:2,name:"Canva Creator Pack",category:"Canva Templates",price:299,old:599,icon:"🎨",desc:"Ready-to-edit templates for creators and small brands."},
  {id:3,name:"30-Day Content Planner",category:"Planners",price:199,old:399,icon:"📊",desc:"Plan a month of consistent content with ease."},
  {id:4,name:"Reels Content Toolkit",category:"Reels & Content",price:399,old:799,icon:"🎬",desc:"Ideas, hooks and resources for short-form video."},
  {id:5,name:"Creator Business Guide",category:"Ebooks & Guides",price:249,old:499,icon:"📚",desc:"A practical guide to building your digital workflow."},
  {id:6,name:"Small Business Social Kit",category:"Social Media Kits",price:449,old:899,icon:"📣",desc:"A starter kit for consistent social media branding."},
  {id:7,name:"Freelancer Productivity Planner",category:"Planners",price:229,old:449,icon:"💼",desc:"Organize clients, tasks, goals and weekly priorities."},
  {id:8,name:"Ultimate Creator Bundle",category:"Premium Bundles",price:999,old:2999,icon:"💎",desc:"A high-value bundle of creator resources and bonuses."}
];

let cart = JSON.parse(localStorage.getItem("tdh-cart") || "[]");
let activeCategory = "All";

function money(n){return "₹" + n.toLocaleString("en-IN")}
function save(){localStorage.setItem("tdh-cart",JSON.stringify(cart)); renderCart();}

function renderProducts(){
  const root = document.getElementById("products");
  const filtered = activeCategory==="All" ? products : products.filter(p=>p.category===activeCategory);
  root.innerHTML = filtered.map(p=>`
    <article class="product">
      <div class="product-img">${p.icon}</div>
      <div class="product-body">
        <span class="tag">${p.category}</span>
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <div class="price"><strong>${money(p.price)}</strong><span class="old">${money(p.old)}</span></div>
        <button class="btn btn-primary" onclick="addToCart(${p.id})">Add to Cart</button>
      </div>
    </article>`).join("");
}

function addToCart(id){
  const p=products.find(x=>x.id===id);
  const found=cart.find(x=>x.id===id);
  if(found) found.qty++;
  else cart.push({...p,qty:1});
  save();
  openCart();
}

function renderCart(){
  document.getElementById("cartCount").textContent=cart.reduce((s,p)=>s+p.qty,0);
  const root=document.getElementById("cartItems");
  if(!cart.length){root.innerHTML='<div class="empty">Your cart is empty.</div>';document.getElementById("cartTotal").textContent=money(0);return}
  root.innerHTML=cart.map(p=>`
    <div class="cart-row">
      <div>${p.icon}</div>
      <div class="grow"><b>${p.name}</b><br><small>${money(p.price)} × ${p.qty}</small></div>
      <button onclick="removeFromCart(${p.id})" aria-label="Remove">×</button>
    </div>`).join("");
  document.getElementById("cartTotal").textContent=money(cart.reduce((s,p)=>s+p.price*p.qty,0));
}

function removeFromCart(id){cart=cart.filter(p=>p.id!==id);save()}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("overlay").classList.remove("show")}

document.getElementById("cartBtn").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("overlay").onclick=closeCart;

document.querySelectorAll(".category-grid button").forEach(btn=>{
  btn.addEventListener("click",()=>{
    activeCategory=btn.dataset.cat;
    renderProducts();
    document.getElementById("shop").scrollIntoView({behavior:"smooth"});
  });
});

document.getElementById("newsletter").addEventListener("submit",e=>{
  e.preventDefault(); alert("Thanks! Newsletter signup is ready for backend integration.");
});

document.getElementById("checkoutBtn").addEventListener("click",()=>{
  if(!cart.length){alert("Your cart is empty.");return}
  alert("Checkout is the next development stage. Payment and secure digital delivery will be connected after the frontend is approved.");
});

renderProducts(); renderCart();
