# The Digital Hub — Frontend Store v2

This version adds the next real storefront stage:
- Home page
- Full Shop page with search, category filters and sorting
- Product detail page with pricing, discount, included items, FAQ and related purchase flow
- Cart using localStorage
- Frontend checkout structure
- Existing The Digital Hub logo
- Responsive mobile/desktop styling

## Open locally
Open `index.html` in a browser. Use `shop.html` to browse the catalog.

## Important
This is still a frontend build. Production must connect:
1. Real database/product catalog
2. Razorpay or Stripe payment gateway
3. Customer accounts/login
4. Secure expiring download links
5. Email delivery
6. Admin dashboard
7. Orders, refunds, coupons and analytics

Sample products/prices are placeholders until the final catalog is approved.
