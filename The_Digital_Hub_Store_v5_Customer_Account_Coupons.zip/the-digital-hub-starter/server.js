require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const helmet = require('helmet');
const morgan = require('morgan');
const Razorpay = require('razorpay');
const nodemailer = require('nodemailer');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const ROOT = __dirname;
const PRIVATE = path.join(ROOT, 'private-files');
let products = JSON.parse(fs.readFileSync(path.join(ROOT, 'products.json'), 'utf8'));
const upload = multer({dest: path.join(ROOT, 'private-files', '.uploads')});
const adminSessions = new Map();
const customerSessions = new Map();
const customersFile = path.join(ROOT, 'customers.json');
const couponsFile = path.join(ROOT, 'coupons.json');
if (!fs.existsSync(customersFile)) fs.writeFileSync(customersFile, '[]');
if (!fs.existsSync(couponsFile)) fs.writeFileSync(couponsFile, JSON.stringify([{code:'WELCOME10',type:'percent',value:10,active:true} ],null,2));
const ordersFile = path.join(ROOT, 'orders.json');
if (!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile, '[]');

app.use(helmet({contentSecurityPolicy:false}));
app.use(morgan('tiny'));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(ROOT, {index:'index.html'}));

const razorpay = new Razorpay({key_id:process.env.RAZORPAY_KEY_ID || 'rzp_test_missing', key_secret:process.env.RAZORPAY_KEY_SECRET || 'missing'});
const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:Number(process.env.SMTP_PORT||587)===465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}}) : null;

function readOrders(){ return JSON.parse(fs.readFileSync(ordersFile,'utf8')); }
function writeOrders(v){ fs.writeFileSync(ordersFile, JSON.stringify(v,null,2)); }
function readCustomers(){return JSON.parse(fs.readFileSync(customersFile,'utf8'));}
function writeCustomers(v){fs.writeFileSync(customersFile,JSON.stringify(v,null,2));}
function readCoupons(){return JSON.parse(fs.readFileSync(couponsFile,'utf8'));}
function customerAuth(req,res,next){const h=req.headers.authorization||'';const t=h.startsWith('Bearer ')?h.slice(7):'';const session=customerSessions.get(t);if(!session||session.expires<Date.now())return res.status(401).json({error:'Login required'});req.customer=session.customer;next();}
function productById(id){ return products.find(p=>p.id===id); }
function makeToken(orderId, productId, exp){
  const payload = `${orderId}.${productId}.${exp}`;
  const sig = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'dev-secret').update(payload).digest('hex');
  return Buffer.from(`${payload}.${sig}`).toString('base64url');
}
function verifyToken(token){
  const raw=Buffer.from(token,'base64url').toString('utf8'); const parts=raw.split('.');
  if(parts.length!==4) throw new Error('Invalid token');
  const [orderId,productId,exp,sig]=parts; if(Number(exp)<Date.now()) throw new Error('Token expired');
  const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET||'dev-secret').update(`${orderId}.${productId}.${exp}`).digest('hex');
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) throw new Error('Invalid signature');
  return {orderId,productId};
}

app.get('/api/products',(req,res)=>res.json(products.map(p=>({...p,priceRupees:p.price/100,mrpRupees:p.mrp/100}))));

app.post('/api/customer/register',(req,res)=>{try{const {name,email,password}=req.body;if(!name||!email||!/^\S+@\S+\.\S+$/.test(email)||!password||password.length<6)return res.status(400).json({error:'Name, valid email and 6+ character password are required'});const customers=readCustomers();if(customers.some(c=>c.email.toLowerCase()===email.toLowerCase()))return res.status(409).json({error:'An account with this email already exists'});const customer={id:crypto.randomUUID(),name,email:email.toLowerCase(),passwordHash:crypto.createHash('sha256').update(password).digest('hex'),createdAt:new Date().toISOString()};customers.push(customer);writeCustomers(customers);const token=crypto.randomBytes(32).toString('hex');customerSessions.set(token,{customer:{id:customer.id,name:customer.name,email:customer.email},expires:Date.now()+7*24*60*60*1000});res.json({token,...customerSessions.get(token).customer});}catch(e){res.status(500).json({error:'Could not create account'});}});
app.post('/api/customer/login',(req,res)=>{const {email,password}=req.body;const c=readCustomers().find(x=>x.email===String(email||'').toLowerCase());const hash=crypto.createHash('sha256').update(password||'').digest('hex');if(!c||c.passwordHash!==hash)return res.status(401).json({error:'Invalid email or password'});const token=crypto.randomBytes(32).toString('hex');customerSessions.set(token,{customer:{id:c.id,name:c.name,email:c.email},expires:Date.now()+7*24*60*60*1000});res.json({token,...customerSessions.get(token).customer});});
app.get('/api/customer/me',customerAuth,(req,res)=>res.json(req.customer));
app.get('/api/customer/orders',customerAuth,(req,res)=>{const orders=readOrders().filter(o=>o.email===req.customer.email&&o.status==='paid').map(o=>({id:o.id,status:o.status,amount:o.amount,email:o.email,items:o.items,downloads:o.downloads||[],createdAt:o.createdAt}));res.json({orders});});
app.post('/api/coupon/validate',(req,res)=>{const code=String(req.body.code||'').trim().toUpperCase();const c=readCoupons().find(x=>x.code===code&&x.active);if(!c)return res.status(404).json({error:'Invalid or inactive coupon'});res.json({code:c.code,type:c.type,value:c.value});});


function adminAuth(req,res,next){const h=req.headers.authorization||''; const t=h.startsWith('Bearer ')?h.slice(7):''; if(!t||!adminSessions.has(t)) return res.status(401).json({error:'Unauthorized'}); next();}
app.post('/api/admin/login',(req,res)=>{const {username,password}=req.body; if(username!==process.env.ADMIN_USERNAME||password!==process.env.ADMIN_PASSWORD) return res.status(401).json({error:'Invalid admin credentials'}); const token=crypto.randomBytes(32).toString('hex'); adminSessions.set(token,Date.now()+8*60*60*1000); res.json({token});});
app.get('/api/admin/products',adminAuth,(req,res)=>res.json(products));
app.get('/api/admin/orders',adminAuth,(req,res)=>res.json(readOrders()));
app.post('/api/admin/products',adminAuth,upload.single('file'),(req,res)=>{try{const {pid,pname,price,mrp,category,desc}=req.body; if(!pid||!pname||!req.file) return res.status(400).json({error:'ID, name and file are required'}); const safe=path.basename(req.file.originalname).replace(/[^a-zA-Z0-9._-]/g,'_'); const finalName=`${pid}-${Date.now()}-${safe}`; fs.renameSync(req.file.path,path.join(PRIVATE,finalName)); const item={id:pid,name:pname,price:Math.round(Number(price)*100),mrp:Math.round(Number(mrp)*100),category,description:desc||'',file:finalName}; const idx=products.findIndex(p=>p.id===pid); if(idx>=0) products[idx]=item; else products.push(item); fs.writeFileSync(path.join(ROOT,'products.json'),JSON.stringify(products,null,2)); res.json(item);}catch(e){console.error(e);res.status(500).json({error:'Could not save product'});}});
app.delete('/api/admin/products/:id',adminAuth,(req,res)=>{const i=products.findIndex(p=>p.id===req.params.id); if(i<0)return res.status(404).json({error:'Product not found'}); products.splice(i,1); fs.writeFileSync(path.join(ROOT,'products.json'),JSON.stringify(products,null,2)); res.json({success:true});});


app.post('/api/create-order', async (req,res)=>{
  try{
    const {items,email,name,coupon}=req.body;
    if(!Array.isArray(items)||!items.length) return res.status(400).json({error:'Cart is empty'});
    if(!email || !/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:'Valid email is required'});
    const clean=[]; let amount=0;
    for(const item of items){
      const p=productById(item.id); const qty=Math.max(1,Math.min(10,Number(item.qty)||1));
      if(!p) return res.status(400).json({error:`Product not found: ${item.id}`});
      clean.push({id:p.id,name:p.name,price:p.price,qty}); amount += p.price*qty;
    }
    let discount=0; let appliedCoupon=null;
    if(coupon){const c=readCoupons().find(x=>x.code===String(coupon).trim().toUpperCase()&&x.active);if(c){discount=c.type==='percent'?Math.round(amount*c.value/100):Math.min(amount,Math.round(c.value*100));appliedCoupon=c.code;}}
    amount=Math.max(100,amount-discount);
    const receipt=`TDH_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    const rpOrder=await razorpay.orders.create({amount,currency:'INR',receipt,notes:{email,coupon:appliedCoupon||''}});
    const orders=readOrders(); orders.push({id:rpOrder.id,receipt,name:name||'',email,items:clean,subtotal:amount+discount,discount, coupon:appliedCoupon,amount,status:'created',createdAt:new Date().toISOString()}); writeOrders(orders);
    res.json({keyId:process.env.RAZORPAY_KEY_ID,orderId:rpOrder.id,amount,currency:'INR'});
  }catch(e){ console.error(e); res.status(500).json({error:'Unable to create payment order. Check Razorpay settings.'}); }
});

app.post('/api/verify-payment', async (req,res)=>{
  try{
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
    const orders=readOrders(); const order=orders.find(o=>o.id===razorpay_order_id);
    if(!order) return res.status(404).json({error:'Order not found'});
    const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET||'missing').update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
    if(expected!==razorpay_signature) return res.status(400).json({error:'Payment verification failed'});
    order.status='paid'; order.paymentId=razorpay_payment_id; order.paidAt=new Date().toISOString();
    const links=order.items.map(i=>({productId:i.id,productName:i.name,url:`${BASE_URL}/download/${makeToken(order.id,i.id,Date.now()+24*60*60*1000)}`}));
    order.downloads=links; writeOrders(orders);
    if(mailer){
      const html=`<h2>Thank you for your purchase!</h2><p>Your Digital Hub order <b>${order.id}</b> is confirmed.</p><ul>${links.map(l=>`<li><a href="${l.url}">${l.productName} — Download</a></li>`).join('')}</ul><p>Links are valid for 24 hours. You can request a fresh link from support if needed.</p>`;
      await mailer.sendMail({from:process.env.FROM_EMAIL,to:order.email,subject:'Your Digital Hub purchase & download links',html});
    }
    res.json({success:true,orderId:order.id,downloads:links});
  }catch(e){ console.error(e); res.status(500).json({error:'Could not verify payment'}); }
});

app.get('/download/:token',(req,res)=>{
  try{
    const {orderId,productId}=verifyToken(req.params.token); const order=readOrders().find(o=>o.id===orderId && o.status==='paid');
    const p=productById(productId); if(!order||!p||!order.items.some(i=>i.id===productId)) return res.status(404).send('Download not available.');
    const file=path.resolve(PRIVATE,p.file); if(!file.startsWith(PRIVATE+path.sep)||!fs.existsSync(file)) return res.status(404).send('Product file has not been uploaded yet.');
    res.download(file,p.file);
  }catch(e){res.status(403).send('This download link is invalid or expired.');}
});

app.post('/api/webhook/razorpay',(req,res)=>{
  const signature=req.headers['x-razorpay-signature'];
  if(!signature || !process.env.RAZORPAY_WEBHOOK_SECRET) return res.status(400).send('Webhook not configured');
  const body=JSON.stringify(req.body); const expected=crypto.createHmac('sha256',process.env.RAZORPAY_WEBHOOK_SECRET).update(body).digest('hex');
  if(expected!==signature) return res.status(400).send('Invalid webhook signature');
  console.log('Razorpay webhook:',req.body.event); res.json({ok:true});
});

app.get('/api/order/:id',(req,res)=>{const o=readOrders().find(x=>x.id===req.params.id); if(!o)return res.status(404).json({error:'Not found'}); res.json({id:o.id,status:o.status,amount:o.amount/100,email:o.email,downloads:o.status==='paid'?o.downloads||[]:[]});});

app.listen(PORT,()=>console.log(`The Digital Hub running at ${BASE_URL}`));
